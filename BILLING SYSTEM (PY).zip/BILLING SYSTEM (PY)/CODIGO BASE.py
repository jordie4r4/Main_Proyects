import tkinter as tk
import random
from tkinter import messagebox, ttk
from datetime import datetime
import random
import os
import threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
import webbrowser

class LoginPage:
    def __init__(self, win):
        self.win = win
        self.win.geometry("1350x750+0+0")
        self.win.title("SampleManagement System")
        
        # Variables
        self.username = tk.StringVar()
        self.password = tk.StringVar()
        self.cust_nm = tk.StringVar()
        self.cust_cot = tk.StringVar()
        self.date_pr = tk.StringVar()
        self.item_pur = tk.StringVar()
        self.item_qty = tk.StringVar()
        self.cone = tk.StringVar()
        self.bill_generated = False
        self.temp_filename = ""
        
        
        # MAIN
        self.title_label = tk.Label(self.win, text="Sample  Management System", font=('Arial', 35, 'bold'), bg="lightgrey", bd=8, relief=tk.GROOVE)
        self.title_label.pack(side=tk.TOP, fill=tk.X)
        
        self.main_frame = tk.Frame(self.win, bg="Lightgrey", bd=6, relief=tk.GROOVE)
        self.main_frame.place(x=250, y=150, width=800, height=450)
        
        self.login_lbl = tk.Label(self.main_frame, text="Sign in", bd=6, relief=tk.GROOVE, anchor=tk.CENTER, bg="Lightgrey", font=('sans-serif', 25, 'bold'))
        self.login_lbl.pack(side=tk.TOP, fill=tk.X)
        
        self.entry_frame = tk.LabelFrame(self.main_frame, text="Fill your information", bd=6, relief=tk.GROOVE, bg="Lightgrey", font=('sans-serif', 25, 'bold'))
        self.entry_frame.pack(fill=tk.BOTH, expand=tk.TRUE)
        
        # Usuario
        self.entus_lbl = tk.Label(self.entry_frame, text="Fill your username:", bg="lightgrey", font=('sans-serif', 15))
        self.entus_lbl.grid(row=0, column=0, padx=10, pady=10, sticky='e')
        
        self.entus_ent = tk.Entry(self.entry_frame, font=('sans-serif', 15), bd=6, textvariable=self.username)
        self.entus_ent.grid(row=0, column=1, padx=10, pady=10)
        
        # Contraseña
        self.entpass_lbl = tk.Label(self.entry_frame, text="Fill your password:", bg="lightgrey", font=('sans-serif', 15))
        self.entpass_lbl.grid(row=1, column=0, padx=10, pady=10, sticky='e')
        
        self.entpass_ent = tk.Entry(self.entry_frame, font=('sans-serif', 15), bd=6, textvariable=self.password, show="*")
        self.entpass_ent.grid(row=1, column=1, padx=10, pady=10)
        
        # Botones
        self.button_frame = tk.LabelFrame(self.entry_frame, text="Options", bg="lightgrey", font=('Arial', 15), bd=7, relief=tk.GROOVE)
        self.button_frame.place(x=20, y=200, width=730, height=85)
        
        self.login_btn = tk.Button(self.button_frame, text="Sign in", font=('Arial', 15), bd=5, width=15, command=self.check_login)
        self.login_btn.grid(row=0, column=0, padx=20, pady=2)
        
        self.billing_btn = tk.Button(self.button_frame, text="Billing", font=('Arial', 15), bd=5, width=15, command=self.billing_sect)
        self.billing_btn.grid(row=0, column=1, padx=20, pady=2)
        self.billing_btn.config(state="disabled")
        
        self.reset_btn = tk.Button(self.button_frame, text="Reset", font=('Arial', 15), bd=5, width=15, command=self.reset)
        self.reset_btn.grid(row=0, column=2, padx=20, pady=2)

    def check_login(self):
        """This funcionts check if the username and password matches stablished here."""
        if self.username.get() == "Admin" and self.password.get() == "12345":
            self.billing_btn.config(state="normal")
        else:
            messagebox.showerror("Error", "User or password invalid.")

    def reset(self):
        """This functions resets the username and password to null"""
        self.username.set("")
        self.password.set("")
        self.billing_btn.config(state="disabled")

    def billing_sect(self):
        self.newWindow = tk.Toplevel(self.win)
        self.app = Window2(self.newWindow)


class Window2:
    def __init__(self, win):
        self.win = win
        self.win.geometry("1350x750+0+0")
        self.win.title("Sample Billing System")
        
        self.title_label = tk.Label(self.win, text="Sample Billing System", font=('Arial', 35, 'bold'), bg="lightgrey", bd=8, relief=tk.GROOVE)
        self.title_label.pack(side=tk.TOP, fill=tk.X)
        
          # Creates the folders if it doesn-t exist
        if not os.path.exists("ARTICULOS"):
            os.makedirs("ARTICULOS")
        if not os.path.exists("CLIENTES"):
            os.makedirs("CLIENTES")
            
          # Incoming Data
        self.entry_frame = tk.LabelFrame(self.win, text="Enter Details", bd=7, relief=tk.GROOVE, bg="Lightgrey", font=('Arial', 20, 'bold'))
        self.entry_frame.place(x=20, y=95, width=500, height=450)  
        
        labels = [
            "Bill Number",
            "Customer Name",
            "Customer Contact",
            "Date",
            "Item Number",  
            "Item Purchased",
            "Item Quantity",
            "Cost of one"
        ]
        
        self.entries = {}
        self.entry_vars = {}
        
        for i, label in enumerate(labels):
            lbl = tk.Label(self.entry_frame, text=label, font=('Arial', 12), bg="Lightgrey", anchor="e")
            lbl.grid(row=i, column=0, padx=10, pady=10, sticky='e')
            
            if label == "Bill Number":
                ent = tk.Entry(self.entry_frame, font=('Arial', 12), bd=2, state='readonly')
                self.generate_bill_number(ent)
            elif label == "Date":
                ent = tk.Entry(self.entry_frame, font=('Arial', 12), bd=2, state='readonly')
                self.set_current_datetime(ent)
            else:
                var = tk.StringVar()
                ent = tk.Entry(self.entry_frame, font=('Arial', 12), bd=2, textvariable=var)
                self.entry_vars[label] = var
            
            ent.grid(row=i, column=1, padx=10, pady=10, sticky='w')
            self.entries[label] = ent
        
        # Bind events for autocomplete
        self.entries["Customer Contact"].bind("<FocusOut>", self.load_customer)
        self.entries["Item Number"].bind("<FocusOut>", self.load_item)
        
        # Calculator
        self.calc_frame = tk.LabelFrame(self.win, bd=5, bg="Lightgrey", relief=tk.GROOVE)
        self.calc_frame.place(x=570, y=110, width=650, height=295)

        # Screen Calculator
        self.calc_input = tk.Entry(self.calc_frame, font=('Arial', 16), bd=5, relief=tk.SUNKEN, justify=tk.RIGHT)
        self.calc_input.grid(row=0, column=0, columnspan=4, padx=5, pady=5, sticky='nsew')

        # Calculator Bottons
        calc_buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('+', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('-', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('*', 3, 3),
            ('0', 4, 0), ('.', 4, 1), ('=', 4, 2), ('/', 4, 3)
        ]

        for text, row, col in calc_buttons:
            btn = tk.Button(self.calc_frame, text=text, font=('Arial', 14), bd=3, relief=tk.RAISED, bg='lightgrey')
            btn.grid(row=row, column=col, padx=3, pady=3, sticky='nsew')
            btn.config(command=lambda x=text: self.click(x))

        # Files and Columns weight configuration
        for i in range(5):
            self.calc_frame.grid_rowconfigure(i, weight=1)
        for i in range(4):
            self.calc_frame.grid_columnconfigure(i, weight=1)

        # Billing  Area
        self.bill_frame = tk.LabelFrame(self.win, bd=8, text="BILL AREA", font=('Arial', 18), bg="Lightgrey", relief=tk.GROOVE)
        self.bill_frame.place(x=570, y=400, width=650, height=295)
        
        self.y_scroll = tk.Scrollbar(self.bill_frame, orient="vertical")
        self.bill_txt = tk.Text(self.bill_frame, bg="white", yscrollcommand=self.y_scroll.set)
        self.y_scroll.config(command=self.bill_txt.yview)
        self.y_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.bill_txt.pack(fill=tk.BOTH, expand=tk.TRUE)

        # Billing Number
        self.default_bill_header()

        # Buttons
        self.button_frame = tk.LabelFrame(self.win, text="Options", bd=5, bg="Lightgrey", font=('Arial', 15))
        self.button_frame.place(x=20, y=500, width=550, height=200)  

        buttons = [
            ("Add", 0, 0), ("Generate", 0, 1), ("Clear", 0, 2),
            ("Total", 1, 0), ("Reset", 1, 1), ("Save", 1, 2)
        ]

        for (text, row, col) in buttons:
            btn = tk.Button(self.button_frame, text=text, font=('Arial', 12), bd=2, width=12, height=3, command=lambda t=text: self.button_click(t))
            btn.grid(row=row, column=col, padx=4, pady=2)

        
        self.print_btn = tk.Button(self.button_frame, text="Print", font=('Arial', 12), bd=2, width=12, height=7, command=self.print_invoice)
        self.print_btn.grid(row=0, column=3, rowspan=2, padx=4, pady=2, sticky='ns')  # Changed sticky to 'ns'


        # 
        self.bill_generated = False
        
    #Functions
    def print_invoice(self):
        if not self.bill_generated:
            messagebox.showerror("Error", "Por favor, genere la factura primero.")
            return
        
        try:
            # Obtains the bill content.
            content = self.bill_txt.get("1.0", tk.END)
            
            # Creates an temporal HTML DOCUMENT
            if not os.path.exists("FACTURAS"):
                os.makedirs("FACTURAS")
            
            self.temp_filename = f"FACTURAS/factura_temp_{self.entries['Bill Number'].get()}.html"
            
            html_content = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Factura</title>
                <style>
                    body {{ font-family: Arial, sans-serif; }}
                    pre {{ white-space: pre-wrap; }}
                </style>
            </head>
            <body>
                <pre>{content}</pre>
                <script>
                    window.onload = function() {{ window.print(); }}
                </script>
            </body>
            </html>
            """
            
            with open(self.temp_filename, 'w', encoding='utf-8') as temp_file:
                temp_file.write(html_content)
            
            # Runs an separated HTML Server
            def run_server():
                httpd = HTTPServer(('', 0), SimpleHTTPRequestHandler)
                port = httpd.server_port
                webbrowser.open(f'http://localhost:{port}/{os.path.basename(self.temp_filename)}')
                httpd.handle_request()
            
            server_thread = threading.Thread(target=run_server)
            server_thread.start()
            
            messagebox.showinfo("Impresión", "Your bill will be opened in your main browser , use the browser functions to print it.")
        
        except Exception as e:
            messagebox.showerror("Error", f"The bill couldn't be printed: {str(e)}")
    
    def load_customer(self, event=None):
        contact = self.entry_vars["Customer Contact"].get()
        if contact:
            customer = self.get_customer(contact)
            if customer:
                self.entry_vars["Customer Name"].set(customer["name"])
            else:
                self.show_popup("Customer", "Customer Contact", "Customer Name")

    def load_item(self, event=None):
        item_number = self.entry_vars["Item Number"].get()
        if item_number:
            item = self.get_item(item_number)
            if item:
                self.entry_vars["Item Purchased"].set(item["name"])
                self.entry_vars["Cost of one"].set(item["cost"])
            else:
                self.show_popup("Item", "Item Number", "Item Purchased", "Cost of one")

    def show_popup(self, entity_type, *fields):
        popup = tk.Toplevel(self.win)
        popup.title(f"Add New {entity_type}")
        
        entries = {}
        for field in fields:
            tk.Label(popup, text=field).pack()
            entries[field] = tk.Entry(popup)
            entries[field].insert(0, self.entry_vars[field].get())
            entries[field].pack()
        
        def save():
            if entity_type == "Customer":
                self.save_customer(entries["Customer Contact"].get(), entries["Customer Name"].get())
            else:  # Item
                self.save_item(entries["Item Number"].get(), entries["Item Purchased"].get(), entries["Cost of one"].get())
            for field, entry in entries.items():
                self.entry_vars[field].set(entry.get())
            popup.destroy()
        
        tk.Button(popup, text="Save", command=save).pack()

    def get_customer(self, contact):
        try:
            with open(os.path.join("CLIENTES", "clientes.txt"), "r") as file:
                for line in file:
                    parts = line.strip().split(",")
                    if parts[0] == contact:
                        return {"contact": parts[0], "name": parts[1]}
        except FileNotFoundError:
            return None
        return None

    def save_customer(self, contact, name):
        with open(os.path.join("CLIENTES", "clientes.txt"), "a") as file:
            file.write(f"{contact},{name}\n")

    def get_item(self, item_number):
        try:
            with open(os.path.join("ARTICULOS", "articulos.txt"), "r") as file:
                for line in file:
                    parts = line.strip().split(",")
                    if parts[0] == item_number:
                        return {"number": parts[0], "name": parts[1], "cost": parts[2]}
        except FileNotFoundError:
            return None
        return None

    def save_item(self, item_number, name, cost):
        with open(os.path.join("ARTICULOS", "articulos.txt"), "a") as file:
            file.write(f"{item_number},{name},{cost}\n")

    def generate_bill_number(self, entry):
        bill_number = random.randint(100000, 999999)
        entry.config(state='normal')
        entry.delete(0, tk.END)
        entry.insert(0, str(bill_number))
        entry.config(state='readonly')
    
    def set_current_datetime(self, entry):
        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        entry.config(state='normal')
        entry.delete(0, tk.END)
        entry.insert(0, current_datetime)
        entry.config(state='readonly')

    def default_bill_header(self):
        self.bill_txt.delete('1.0', tk.END)
        self.bill_txt.insert(tk.END, "\t\t\tSample Billing Name\n")
        self.bill_txt.insert(tk.END, "\t\tSample Addres. \n")
        self.bill_txt.insert(tk.END, "\t\t\tSample Contact EMAIL and Phone\n")
        self.bill_txt.insert(tk.END, "="*76 + "\n")
        self.bill_txt.insert(tk.END, f"Bill Number : {self.entries['Bill Number'].get()}\n")

    def button_click(self, button_text):
        if button_text == "Add":
            self.add_item()
        elif button_text == "Generate":
            self.generate_bill()
        elif button_text == "Clear":
            self.clear_items()
        elif button_text == "Total":
            self.calculate_total()
        elif button_text == "Reset":
            self.reset_all()
        elif button_text == "Save":
            self.save_bill()

    def add_item(self):
        if not self.bill_generated:
            messagebox.showerror("Error", "Please generate the bill first.")
            return
        item = self.entry_vars["Item Purchased"].get()
        quantity = self.entry_vars["Item Quantity"].get()
        cost = self.entry_vars["Cost of one"].get()
        
        if item and quantity and cost:
            try:
                quantity = int(quantity)
                cost = float(cost)
                total = quantity * cost
                
                self.bill_txt.insert(tk.END, f"{item}\t\t{quantity}\t\t${cost:.2f}\t\t${total:.2f}\n")
                
                # Clear the entry fields
                self.entry_vars["Item Purchased"].set("")
                self.entry_vars["Item Quantity"].set("")
                self.entry_vars["Cost of one"].set("")
            except ValueError:
                messagebox.showerror("Error", "Please enter valid numbers for quantity and cost.")
        else:
            messagebox.showerror("Error", "Please fill all the item details.")

    def generate_bill(self):
        if not self.bill_generated:
            self.bill_txt.delete('1.0', tk.END)
            self.bill_txt.insert(tk.END, "\t\t\tSample Company Name\n")
            self.bill_txt.insert(tk.END, "\t\tSample Addres. \n")
            self.bill_txt.insert(tk.END, "\t\t\tSample EMAIL and Phone\n")
            self.bill_txt.insert(tk.END, "="*76 + "\n")
            self.bill_txt.insert(tk.END, f"Bill Number : {self.entries['Bill Number'].get()}\n")
            self.bill_txt.insert(tk.END, f"Customer Name : {self.entry_vars['Customer Name'].get()}\n")
            self.bill_txt.insert(tk.END, f"Customer Contact : {self.entry_vars['Customer Contact'].get()}\n")
            self.bill_txt.insert(tk.END, f"Date : {self.entries['Date'].get()}\n")
            self.bill_txt.insert(tk.END, "="*76 + "\n")
            self.bill_txt.insert(tk.END, "Product Name\t\tQuantity\t\tPer Cost\t\tTotal\n")
            self.bill_txt.insert(tk.END, "="*76 + "\n")
            self.bill_generated = True
        else:
            messagebox.showinfo("Info", "Bill has already been generated.")

    def clear_items(self):
        if self.bill_generated:
            # Find the start and end index of the product list
            start_index = "11.0"
            end_index = self.bill_txt.index("end-1c")
            
            # Get the content
            content = self.bill_txt.get("1.0", "end-1c")
            lines = content.split('\n')
            
            # Find the last product line
            last_product_line = -1
            for i, line in enumerate(reversed(lines)):
                if line.strip() and not line.startswith(("=", "Total")):
                    last_product_line = len(lines) - i - 1
                    break
            
            if last_product_line != -1:
                # Delete only the last product line
                self.bill_txt.delete(f"{last_product_line+1}.0", f"{last_product_line+2}.0")
                
                # If it was the last product, also remove the Total line if it exists
                if "Total" in lines[last_product_line+1]:
                    self.bill_txt.delete(f"{last_product_line+1}.0", "end-1c")
                    self.bill_txt.insert("end", "="*76 + "\n")
        else:
            messagebox.showinfo("Info", "No items to clear. Generate the bill first.")

    def reset_all(self):
        # Clear all entry fields except Date
        for key, var in self.entry_vars.items():
            if key != "Date":
                var.set("")
        
        # Generate new bill number
        new_bill_number = str(random.randint(100000, 999999))
        self.entries['Bill Number'].config(state='normal')
        self.entries['Bill Number'].delete(0, tk.END)
        self.entries['Bill Number'].insert(0, new_bill_number)
        self.entries['Bill Number'].config(state='readonly')
        
        # Clear the bill text area but keep the header
        self.bill_txt.delete('1.0', tk.END)
        self.default_bill_header()
        
        # Reset the bill_generated flag
        self.bill_generated = False

        messagebox.showinfo("Reset", "All fields have been reset and a new bill number has been generated.")

    def calculate_total(self):
        if not self.bill_generated:
            messagebox.showerror("Error", "Please generate the bill first.")
            return

        total = 0
        content = self.bill_txt.get("1.0", tk.END)
        lines = content.split('\n')
        for line in lines:
            if line.strip() and not line.startswith(("=", "Product", "Bill", "Customer", "Date", "Total")):
                parts = line.split('\t')
                if len(parts) >= 4:
                    try:
                        total += float(parts[-1].replace('$', ''))
                    except ValueError:
                        pass
        
        # Remove previous total if exists
        for i, line in enumerate(reversed(lines)):
            if line.strip().startswith("Total"):
                self.bill_txt.delete(f"end-{i+1}l", "end-1c")
                break
        
        # Insert new total
        self.bill_txt.insert(tk.END, f"\n{'=' * 76}\n")
        self.bill_txt.insert(tk.END, f"Total\t\t\t\t\t${total:.2f}\n")
        self.bill_txt.insert(tk.END, f"{'=' * 76}\n")

    def save_bill(self):
        if not self.bill_generated:
            messagebox.showerror("Error", "Please generate the bill first.")
            return
        
        try:
            content = self.bill_txt.get("1.0", tk.END)
            
            # Create FACTURAS folder if it doesn't exist
            if not os.path.exists("FACTURAS"):
                os.makedirs("FACTURAS")
            
            file_name = f"FACTURAS/bill_{self.entries['Bill Number'].get()}.txt"
            with open(file_name, "w", encoding="utf-8") as file:
                file.write(content)
            messagebox.showinfo("Bill Saved", f"The bill has been saved as {file_name}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save the bill: {str(e)}")
    
    def click(self, key):
        if key == '=':
            result = eval(self.calc_input.get())
            self.calc_input.delete(0, tk.END)
            self.calc_input.insert(tk.END, str(result))
        elif key == 'C':
            self.calc_input.delete(0, tk.END)
        else:
            self.calc_input.insert(tk.END, key)
    

def main():
    win = tk.Tk()
    app = LoginPage(win)
    win.mainloop()

if __name__ == "__main__":
    main()