

import math
import os
from random import randint
from collections import deque
from enum import Enum

import pygame
from pygame.locals import *


FPS = 60
ANIMATION_SPEED = 0.18
WIN_WIDTH = 284 * 2
WIN_HEIGHT = 512


MENU_FONT_SIZE = 48
BUTTON_WIDTH = 200
BUTTON_HEIGHT = 50
BUTTON_PADDING = 20
TITLE_FONT_SIZE = 64

MOUSEMOTION = pygame.MOUSEMOTION
MOUSEBUTTONUP = pygame.MOUSEBUTTONUP
KEYUP = pygame.KEYUP
K_ESCAPE = pygame.K_ESCAPE
K_PAUSE = pygame.K_p
K_p = pygame.K_p
K_UP = pygame.K_UP
K_RETURN = pygame.K_RETURN
K_SPACE = pygame.K_SPACE
QUIT = pygame.QUIT
SRCALPHA = pygame.SRCALPHA

class GameState(Enum):
    MENU = 1
    PLAYING = 2
    GAME_OVER = 3

class Button:
    def __init__(self, x, y, width, height, text, color=(73, 73, 73), hover_color=(93, 93, 93)):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.is_hovered = False
        self.font = pygame.font.SysFont(None, 36)
        
    def draw(self, surface):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        pygame.draw.rect(surface, (255, 255, 255), self.rect, 2, border_radius=12)
        
        text_surface = self.font.render(self.text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=self.rect.center)
        surface.blit(text_surface, text_rect)
        
    def handle_event(self, event):
        if event.type == MOUSEMOTION:
            self.is_hovered = self.rect.collidepoint(event.pos)
        elif event.type == MOUSEBUTTONUP and self.is_hovered:
            return True
        return False

class Bird(pygame.sprite.Sprite):
    
    WIDTH = HEIGHT = 32
    SINK_SPEED = 0.18
    CLIMB_SPEED = 0.3
    CLIMB_DURATION = 333.3
    MAX_CLIMB_SPEED = 10
    MAX_SINK_SPEED = 10
    BOOST_SPEED = -5  

    def __init__(self, x, y, msec_to_climb, images):
        super(Bird, self).__init__()
        self.x, self.y = x, y
        self.msec_to_climb = msec_to_climb
        self._img_wingup, self._img_wingdown = images
        self._mask_wingup = pygame.mask.from_surface(self._img_wingup)
        self._mask_wingdown = pygame.mask.from_surface(self._img_wingdown)
        self.velocity = 0

    def update(self, delta_frames=1):
        if self.msec_to_climb > 0:
            frac_climb_done = 1 - self.msec_to_climb/Bird.CLIMB_DURATION
            self.velocity = Bird.BOOST_SPEED * (1 - frac_climb_done**2)
            self.velocity = max(self.velocity, -Bird.MAX_CLIMB_SPEED)
            self.msec_to_climb -= frames_to_msec(delta_frames)
        else:
            self.velocity += Bird.SINK_SPEED * frames_to_msec(delta_frames) / 20
            self.velocity = min(self.velocity, Bird.MAX_SINK_SPEED)

        self.y += self.velocity

    def flap(self):
        self.msec_to_climb = Bird.CLIMB_DURATION
        self.velocity = Bird.BOOST_SPEED  

    @property
    def image(self):
        if pygame.time.get_ticks() % 500 >= 250:
            return self._img_wingup
        else:
            return self._img_wingdown

    @property
    def mask(self):
        if pygame.time.get_ticks() % 500 >= 250:
            return self._mask_wingup
        else:
            return self._mask_wingdown

    @property
    def rect(self):
        return pygame.Rect(self.x, self.y, Bird.WIDTH, Bird.HEIGHT)

class PipePair(pygame.sprite.Sprite):
    """Represents an obstacle."""
    WIDTH = 80
    PIECE_HEIGHT = 32
    ADD_INTERVAL = 3000

    def __init__(self, pipe_end_img, pipe_body_img):
        super(PipePair, self).__init__()
        self.x = float(WIN_WIDTH - 1)
        self.score_counted = False

        self.image = pygame.Surface((PipePair.WIDTH, WIN_HEIGHT), SRCALPHA)
        self.image.convert()
        self.image.fill((0, 0, 0, 0))
        total_pipe_body_pieces = int(
            (WIN_HEIGHT -
             3 * Bird.HEIGHT -
             3 * PipePair.PIECE_HEIGHT) /
            PipePair.PIECE_HEIGHT
        )
        self.bottom_pieces = randint(1, total_pipe_body_pieces)
        self.top_pieces = total_pipe_body_pieces - self.bottom_pieces

        for i in range(1, self.bottom_pieces + 1):
            piece_pos = (0, WIN_HEIGHT - i*PipePair.PIECE_HEIGHT)
            self.image.blit(pipe_body_img, piece_pos)
        bottom_pipe_end_y = WIN_HEIGHT - self.bottom_height_px
        bottom_end_piece_pos = (0, bottom_pipe_end_y - PipePair.PIECE_HEIGHT)
        self.image.blit(pipe_end_img, bottom_end_piece_pos)

      
        for i in range(self.top_pieces):
            self.image.blit(pipe_body_img, (0, i * PipePair.PIECE_HEIGHT))
        top_pipe_end_y = self.top_height_px
        self.image.blit(pipe_end_img, (0, top_pipe_end_y))

        self.top_pieces += 1
        self.bottom_pieces += 1
        self.mask = pygame.mask.from_surface(self.image)

    @property
    def top_height_px(self):
        return self.top_pieces * PipePair.PIECE_HEIGHT

    @property
    def bottom_height_px(self):
        return self.bottom_pieces * PipePair.PIECE_HEIGHT

    @property
    def visible(self):
        return -PipePair.WIDTH < self.x < WIN_WIDTH

    @property
    def rect(self):
        return pygame.Rect(self.x, 0, PipePair.WIDTH, PipePair.PIECE_HEIGHT)

    def update(self, delta_frames=1):
        self.x -= ANIMATION_SPEED * frames_to_msec(delta_frames)

    def collides_with(self, bird):
        return pygame.sprite.collide_mask(self, bird)

def load_images():
    def load_image(img_file_name):
        file_name = os.path.join('.', 'images', img_file_name)
        img = pygame.image.load(file_name)
        img.convert()
        return img

    return {'background': load_image('background.png'),
            'pipe-end': load_image('pipe-end.png'),
            'pipe-body': load_image('pipe-body.png'),
            'bird-wingup': load_image('bird_wing_up.png'),
            'bird-wingdown': load_image('bird_wing_down.png')}

def frames_to_msec(frames, fps=FPS):
    return 1000.0 * frames / fps

def msec_to_frames(milliseconds, fps=FPS):
    return fps * milliseconds / 1000.0

class Game:
    def __init__(self):
        pygame.init()
        self.display_surface = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
        pygame.display.set_caption('Pygame Flappy Bird')
        
        self.clock = pygame.time.Clock()
        self.score_font = pygame.font.SysFont(None, 32, bold=True)
        self.menu_font = pygame.font.SysFont(None, MENU_FONT_SIZE, bold=True)
        self.title_font = pygame.font.SysFont(None, TITLE_FONT_SIZE, bold=True)
        
        self.images = load_images()
        self.state = GameState.MENU
        self.high_score = 0
        
        
        button_y = WIN_HEIGHT // 2
        self.play_button = Button(
            WIN_WIDTH // 2 - BUTTON_WIDTH // 2,
            button_y,
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Play"
        )
        
        self.menu_button = Button(
            WIN_WIDTH // 2 - BUTTON_WIDTH // 2,
            button_y + BUTTON_HEIGHT + BUTTON_PADDING,
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Menu"
        )
        
        self.quit_button = Button(
            WIN_WIDTH // 2 - BUTTON_WIDTH // 2,
            button_y + 2 * (BUTTON_HEIGHT + BUTTON_PADDING),
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "Quit"
        )
        
    def reset_game(self):
        self.bird = Bird(50, int(WIN_HEIGHT/2 - Bird.HEIGHT/2), 2,
                        (self.images['bird-wingup'], self.images['bird-wingdown']))
        self.pipes = deque()
        self.frame_clock = 0
        self.score = 0
        self.paused = False
        
    def draw_menu(self):
      
        for x in (0, WIN_WIDTH / 2):
            self.display_surface.blit(self.images['background'], (x, 0))
            
    
        title = self.title_font.render("Flappy Bird", True, (255, 255, 255))
        title_rect = title.get_rect(centerx=WIN_WIDTH // 2, y=50)
        self.display_surface.blit(title, title_rect)
        
       
        high_score_text = self.menu_font.render(f"High Score: {self.high_score}", True, (255, 255, 255))
        high_score_rect = high_score_text.get_rect(centerx=WIN_WIDTH // 2, y=150)
        self.display_surface.blit(high_score_text, high_score_rect)
        
   
        self.play_button.draw(self.display_surface)
        self.quit_button.draw(self.display_surface)
        
    def draw_game_over(self):
     
        for x in (0, WIN_WIDTH / 2):
            self.display_surface.blit(self.images['background'], (x, 0))
            
   
        game_over = self.title_font.render("Game Over", True, (255, 255, 255))
        game_over_rect = game_over.get_rect(centerx=WIN_WIDTH // 2, y=50)
        self.display_surface.blit(game_over, game_over_rect)
        
  
        score_text = self.menu_font.render(f"Score: {self.score}", True, (255, 255, 255))
        score_rect = score_text.get_rect(centerx=WIN_WIDTH // 2, y=150)
        self.display_surface.blit(score_text, score_rect)
        

        self.play_button.draw(self.display_surface)
        self.menu_button.draw(self.display_surface)
        self.quit_button.draw(self.display_surface)
        
    def run(self):
        done = False
        while not done:
            self.clock.tick(FPS)
            
            if self.state == GameState.MENU:
                for event in pygame.event.get():
                    if event.type == QUIT:
                        done = True
                    elif self.play_button.handle_event(event):
                        self.state = GameState.PLAYING
                        self.reset_game()
                    elif self.quit_button.handle_event(event):
                        done = True
                        
                self.draw_menu()
                
            elif self.state == GameState.PLAYING:
                if not (self.paused or self.frame_clock % msec_to_frames(PipePair.ADD_INTERVAL)):
                    pp = PipePair(self.images['pipe-end'], self.images['pipe-body'])
                    self.pipes.append(pp)

                for event in pygame.event.get():
                    if event.type == QUIT:
                        done = True
                    elif event.type == KEYUP and event.key == K_ESCAPE:
                        self.state = GameState.MENU
                    elif event.type == KEYUP and event.key in (K_PAUSE, K_p):
                        self.paused = not self.paused
                    elif event.type == MOUSEBUTTONUP or (event.type == KEYUP and
                            event.key in (K_UP, K_RETURN, K_SPACE)):
                        self.bird.msec_to_climb = Bird.CLIMB_DURATION

                if self.paused:
                    continue

      
                pipe_collision = any(p.collides_with(self.bird) for p in self.pipes)
                if pipe_collision or 0 >= self.bird.y or self.bird.y >= WIN_HEIGHT - Bird.HEIGHT:
                    self.high_score = max(self.high_score, self.score)
                    self.state = GameState.GAME_OVER
                    continue

        
                for x in (0, WIN_WIDTH / 2):
                    self.display_surface.blit(self.images['background'], (x, 0))

                while self.pipes and not self.pipes[0].visible:
                    self.pipes.popleft()

                for p in self.pipes:
                    p.update()
                    self.display_surface.blit(p.image, p.rect)

                self.bird.update()
                self.display_surface.blit(self.bird.image, self.bird.rect)

               
                for p in self.pipes:
                    if p.x + PipePair.WIDTH < self.bird.x and not p.score_counted:
                        self.score += 1
                        p.score_counted = True

                score_surface = self.score_font.render(str(self.score), True, (255))
                score_surface = self.score_font.render(str(self.score), True, (255, 255, 255))
                score_x = WIN_WIDTH/2 - score_surface.get_width()/2
                self.display_surface.blit(score_surface, (score_x, PipePair.PIECE_HEIGHT))

                self.frame_clock += 1
                
            elif self.state == GameState.GAME_OVER:
                for event in pygame.event.get():
                    if event.type == QUIT:
                        done = True
                    elif self.play_button.handle_event(event):
                        self.state = GameState.PLAYING
                        self.reset_game()
                    elif self.menu_button.handle_event(event):
                        self.state = GameState.MENU
                    elif self.quit_button.handle_event(event):
                        done = True
                        
                self.draw_game_over()
            
            pygame.display.flip()
        
        pygame.quit()
        
def load_images():
    def load_image(img_file_name):
      
        base_path = os.path.dirname(os.path.abspath(__file__))
        file_name = os.path.join(base_path, 'images', img_file_name)
        try:
            img = pygame.image.load(file_name)
            img.convert()
            return img
        except pygame.error as e:
            print(f"No se pudo cargar la imagen: {file_name}")
            print(f"Error: {e}")
            raise SystemExit(e)

    return {'background': load_image('background.png'),
            'pipe-end': load_image('pipe_end.png'),
            'pipe-body': load_image('pipe_body.png'),
            'bird-wingup': load_image('bird_wing_up.png'),
            'bird-wingdown': load_image('bird_wing_down.png')}

def main():
    """The application's entry point."""
    game = Game()
    game.run()
    

if __name__ == '__main__':
    main()